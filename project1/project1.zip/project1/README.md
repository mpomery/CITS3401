Issues:

* Palo in OpenOffice suddenly deciding to break
* Numerous Name and Value errors in Excel, with no answers to be found researching
* PALO.SETDATA deciding to nameerror, 